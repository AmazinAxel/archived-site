<?
$SWRYear = 2022;
$lastCleaned = "December 2nd, 2022";