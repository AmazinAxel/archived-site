<?php // Alec'sCP Settings

/* Alec's Control Panel Settings */
/**/ $domain = "https://alecshome.com/AlecsCP"; // Enter full (case-sensitive) application domain here
/**/ $password = "AlecsHomeAdmin15!"; // Enter plain-text password here (insecure)
/**/ $version = '1.127'; // Change this number for cache and organization purposes
/***  The lock feature has been moved to the Options page. ***/

//// These settings are not accessible from the AlecsCP Dashboard and can
//// only be modified in this file, thus making it more secure.