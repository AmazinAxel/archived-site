ADDING THE REMINDER CRONJOB: 
Add the cronjob to run the php file, '/usr/bin/php /home/u245038734/domains/alecshome.com/public_html/AlecsCP/other/cron/reminders.php' at 1:00 PM and 8:00 PM every day to check for reminders. 0 0, 12 * * * 
