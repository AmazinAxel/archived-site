<? #calc health by finding how many reqwuests to the login page wwere made recentgly and how many failed attempts there were, find if the total usage of space on server is too high, or if inode count is too high, also check for too much data usage by AlecsCP and related programs, also shows lower health when development mode is enabled, too many quickshare uploaded files, cache not cleared in a while 
function calcHealth() {
	
}